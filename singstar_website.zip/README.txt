SING STAR COLLECTION WEBSITE

1. Upload index.html to your web hosting public_html (or equivalent).
2. Open the site in a browser.
3. Edit the `links` object near the bottom of index.html and replace # with your own authorized/public URLs.
4. This template intentionally does not bypass Google Sites/Gmail permissions.

The category structure follows the publicly visible navigation of the referenced Google Site.
